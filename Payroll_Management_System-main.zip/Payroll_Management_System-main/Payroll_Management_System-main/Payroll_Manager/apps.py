from django.apps import AppConfig


class PayrollManagerConfig(AppConfig):
    name = 'payroll_manager'
